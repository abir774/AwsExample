"""
Your module description
"""
"""firstString = "watsssser"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
name = input("What is your name? ")
print(name5)
"""
name = input("Whatzzzzz is your name? ")
color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{}, you like a {} {}!".format(name,name,color,name,animal,animal))